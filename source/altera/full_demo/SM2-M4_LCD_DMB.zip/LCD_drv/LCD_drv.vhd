library ieee;
use ieee.std_logic_1164.all;
use ieee.std_logic_unsigned.all;
use ieee.numeric_std.all;
-----------------------------------------------------------------------------------------------------------
--- 640 * 480 LCD Drive
entity LCD_drv is
port(

		nOE			: in std_logic;												-- SRAM Read Enable
		P_CNT		: in std_logic_vector(9 downto 0);							-- Pixel counter (1 horizontal Line)
		H_CNT		: in std_logic_vector(8 downto 0);							-- Horizontal counter (1 vertical Line)
		
		HS			: in std_logic;												-- Horizontal sync
		VS			: in std_logic;												-- Vetical sync
		SRAM2_DATA	: in std_logic_vector(15 downto 0);

		-----LCD DRIVER
		LHS			: out std_logic;
		LVS			: out std_logic;												
		LBIAS		: out std_logic;
		RD2_add		: out std_logic_vector(17 downto 0);						-- SRAM2 READ address
		HOST_DATA	: out std_logic_vector(15 downto 0);
		SRAM_nOE	: buffer std_logic
			
	);
	
end LCD_drv;

architecture a of LCD_drv is 

signal rd_add_temp2	: std_logic_vector(17 downto 0);
signal data_temp2 	: std_logic_vector(15 downto 0);


begin

	LVS <= VS;
	LHS <= HS;
------------------------------------------------------------------------------------------------------------
-- LCD DATA Enable
------------------------------------------------------------------------------------------------------------	
	LBIAS <= '1' when (P_CNT >= 20 and P_CNT <= 339)and( H_CNT >= 7 and H_CNT <= 246) else '0'; 
	SRAM_nOE <= nOE;

------------------------------------------------------------------------------------------------------------
--SRAM Read Address
------------------------------------------------------------------------------------------------------------
	RD2_add <= ((((H_CNT - 7)) * "101000000") + (P_CNT - 20));       
		
------------------------------------------------------------------------------------------------------------
-- Video Data output
------------------------------------------------------------------------------------------------------------

	process(SRAM_nOE)
	begin
		if (SRAM_nOE'event and SRAM_nOE = '1')then
			data_temp2 <= SRAM2_DATA;
		end if;
	end process;

	HOST_DATA <= data_temp2;-- when (P_CNT < 10) else data_temp2;
---------------------------------------------------------------------------------------------------------------------	
end a;